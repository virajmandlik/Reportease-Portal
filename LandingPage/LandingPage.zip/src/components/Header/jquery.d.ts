declare module 'jquery' {
    var $: any;
    export = $;
  }
  