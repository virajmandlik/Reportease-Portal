// src/types/wow.d.ts
declare module 'wow.js' {
    export default class WOW {
      constructor(options?: any);
      init(): void;
    }
  }
  